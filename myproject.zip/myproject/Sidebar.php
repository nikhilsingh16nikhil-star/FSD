                 <nav class="navbar   nav text-info">

                 
                    <div class="profile">
                <img src="<?php
        if(isset($_SESSION['pic'])){
            echo $_SESSION['pic'];
        }
    ?>" alt=" "/>
                 </div>
                    <ul class="navbar-nav flex-column w-100">
                        <li class="nav-item px-1"><a  class="nav-link" href="dashboard.php"><i class="fa-regular fa-house"></i>Dashboard</a></li>

  <li class="nav-item p-1"><a href="#expenseMenu" class="nav-link"  data-bs-toggle="collapse"><i class="fa-solid fa-bars"></i> Expense </a>  
      <ul class="collapse navbar-nav ps-3" id="expenseMenu">
         <li class="nav-item">
             <a href="AddExpense.php" class="nav-link"><i class="fa-solid fa-arrow-right"></i>  Add Expense </a>
        </li>

        <li class="nav-item">
            <a href="MangeExpense.php" class="nav-link"><i class="fa-solid fa-arrow-right"></i>  Mange Expense  </a> </li>
    </ul>
</li>
             <li class="nav-item px-1"><a href="#report" class="nav-link" data-bs-toggle="collapse"><i class="fa-solid fa-bars"></i>Expense Report</a>
                      <ul class="collapse navbar-nav ps-3" id="report">
            <li class="nav-item"><a href="DaywiseExpense.php" class="nav-link"><i class="fa-solid fa-arrow-right"></i>Daywise Report </a> </li>
          <li class="nav-item"><a href="Monthwise_Report.php" class="nav-link"><i class="fa-solid fa-arrow-right"></i>Monthwise Report </a> </li>
            <li class="nav-item"><a href="Yearwise_Report.php" class="nav-link"><i class="fa-solid fa-arrow-right"></i>Yearwise Report </a> </li>

                      </ul>
                        </li>

                        <li class="nav-item px-1"><a href="UserProfile.php" class="nav-link"><i class="fa-solid fa-user"></i>Profile</a></li>
                        <li class="nav-item px-1"><a href="Profile_Pic.php" class="nav-link"><i class="fa-regular fa-camera"></i>Upload Profile Pic</a></li>
                        <li class="nav-item px-1"><a href="ChangePassword.php" class="nav-link"><i class="fa-solid fa-file-pen"></i>Change Password</a></li>
                        <li class="nav-item px-1"><a href="logout.php" class="nav-link"><i class="fa-solid fa-arrow-right-from-bracket"></i>Logout</a></li>

                    </ul>

                 </nav>
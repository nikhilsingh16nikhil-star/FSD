<?php
session_start();
if(!isset($_SESSION['name'])){
    header("location:login.php");
}
$con = mysqli_connect("localhost", "root", "", "dets_db");
$message = "";
$messageClass = "";
$submitted = isset($_POST['btnupdate']);

if($submitted){
    $old = $_POST['userO'];
    $new = $_POST['userP'];
    $cnew = $_POST['userCP'];

    if($new !== $cnew){
        $message = "Password and Confirm Password do not match";
        $messageClass = "unsign";
    }
    else{
        $qry = "SELECT * FROM tbluser WHERE userid = $_SESSION[uid] AND password = '$old'";
        $result = mysqli_query($con, $qry);
        if(mysqli_num_rows($result) > 0){
            $qry = "UPDATE tbluser SET password = '$new' WHERE userid = $_SESSION[uid]";
            mysqli_query($con, $qry);
            $message = "Password Updated Successfully";
            $messageClass = "sign";
            header("location:dashboard.php");
        }
        else{
            $message = "Old Password is incorrect";
            $messageClass = "unsign";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<style>

    
    
body{
    display:flex;
    justify-content:center;
    align-items:center;
    min-height:100vh;
    background-image:url("https://github.com/nikhilsingh16nikhil-star/FSD/blob/main/WhatsApp%20Image%202026-07-10%20at%208.02.25%20PM.jpeg?raw=true");
    background-size:cover;
    background-position:center;
    background-repeat:no-repeat;
    color: #FFFBDC;
}
.box{
    width: 300px;
    padding: 30px;
    background: rgba(255, 255, 255, 0.12);
    backdrop-filter: blur(18px);
    border: 1px solid rgba(255, 255, 255, 0.25);
    border-radius: 20px;
    box-shadow: 0, 15px, 35px, rgba(0, 0, 0, 0.4);
    text-align: center;
}
.box h2{
    color:rgba(0, 0, 0, 0.458); 
}

 .icon{
    width:70px;
    height:70px;
    margin:auto;
    border-radius:50%;
    background:linear-gradient(135deg,#6A11CB,#2575FC);
    display:flex;
    justify-content:center;
    align-items:center;
    font-size:35px;
    color:white;
    box-shadow:0 8px 20px rgba(37,117,252,.5);
}
    form{
        margin-left: 10px;
        margin-top: 20px;
    }
    .i{
        width: 280px;
        margin-left: 5px;
        height: 30px;
        border-radius: 10px;
        border: none;
        color: #2D1B69
    }
    .i::placeholder{
        padding-left: 20px;
       color: #8A8A8A;

    }
   
    .btn{
        width: 300px;
        height: 35px;
         background:linear-gradient(135deg,#6A11CB,#2575FC);
        color: white;
        font-size: large;
        letter-spacing: 1px;
        border-radius: 15px;
        border:none;
        cursor: pointer;
    }
    .btn:hover{
        box-shadow: 0 10px 20px rgba(37, 117, 255, 0.5);
        color: tomato;
    }
    a{
        text-decoration: none;
        margin-top: 5px;
        margin-left: 20px;
        color: #190f40;
    
    }
    a:hover{
        color: tomato;
    }
    .sign{
        color:green;
}
.unsign{
    color:red;
}
   

</style>

</head>
<body>
    <div class="box">
        <div class="icon">
        <i class="fa-solid fa-user"></i>
        </div>
        <h2>Create New Account</h2>
        <form method="post" >
            <?php if(!empty($message)) { echo "<p class='$messageClass'>$message</p>"; } ?>
            
             <input type="Password" name="userO" placeholder="Old Password" value="" required  class="i"/><br><br>
            <input id="n1" type="password" name="userP" placeholder=" New Password" value="" required class="i"/><br><br>
            <input id="n2" type="password" name="userCP" placeholder="Confirm Password" value="" required class="i"/><br><br>
                   <input type="submit" name="btnupdate"  value="Change Password"    class="btn"/>

        </form>

    </div>
    
</body>
</html>
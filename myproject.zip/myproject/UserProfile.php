<?php

session_start();
if(!isset($_SESSION['name'])){
    header("location:login.php");
}
 $con = mysqli_connect("localhost", "root","","dets_db");
    if(isset($_POST['btnupdate'])){
        $name = $_POST['txtfname'];
        $no = $_POST['txtno'];
        $qry = "update tbluser set fullname='$name', mobilenumber=$no where userid=$_SESSION[uid]";
        mysqli_query($con, $qry);
    }
        $qry = "select * from tbluser where userid = $_SESSION[uid]";
        $result = mysqli_query($con, $qry);
        $row = mysqli_fetch_array($result);
        $_SESSION['name'] = $row[1];
    
    mysqli_close($con);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link  rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12 header">
                <!-- Header Design Come Here -->
                 <?php
                 include("Header.php");
                 ?>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-2 sidebar">
                <!-- Header Design of sidemenu -->
                 <?php
                  include("sidebar.php");
                 ?>
            </div>
            <div class="col-sm-10 content">
                <!-- Content Area -->
                 <form method="post">
                    <label class="add">Full Name</label><br>
          <input type="text" name="txtfname"  value="<?php if(isset($row[1])) echo $row[1]; ?>"   class="A"/><br><br>
            <label class="add">Email ID</label><br>
                 <input type="email" name="UserE"  value="<?php if(isset($row[1])) echo $row[2]; ?>"   class="A"/><br><br>
                  <label class="add">Mobile Number</label><br>
                 <input type="number" name="txtno"  value="<?php if(isset($row[1])) echo $row[3]; ?>"   class="A"/>
             <input type="submit" name="btnupdate"  value="Update Profile"    class="Uprofile"/>
          </form>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12 footer">
                <!-- footer Design Come Here -->
                 <footer>
                  <?php
                        include("Footer.php");
                  ?>

                 </footer>
            </div>
        </div>
    </div>
</body>
</html>
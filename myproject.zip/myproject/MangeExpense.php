<?php

session_start();
if(!isset($_SESSION['name'])){
    header("location:login.php");
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link  rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12 header">
                <!-- Header Design Come Here -->
                 <?php
                 include("Header.php");
                 ?>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-2 sidebar">
                <!-- Header Design of sidemenu -->
                 <?php
                  include("sidebar.php");
                 ?>
            </div>
            
          <div class="col-sm-10 p-3 content">

    <h2 class="mb-3">Expense Details</h2>

    <table class="table table-striped table-bordered">
        <thead class="table-primary">
            <tr>
                <th>Expense Date</th>
                <th>Category</th>
                <th>Expense Item Name</th>
                <th>Expense Amount</th>
                <th>Action</th>
            </tr>
        </thead>

        <tbody>

        <?php
        $con = mysqli_connect("localhost","root","","dets_db");
        $uid = isset($_SESSION['uid']) ? (int)$_SESSION['uid'] : 0;

        $qry = "SELECT * FROM tblexpence
                WHERE userid = $uid
                ORDER BY expensedate DESC";

        $result = mysqli_query($con,$qry);

        while($row=mysqli_fetch_array($result))
        {
            echo "<tr>";
            echo "<td>".$row[2]."</td>";
            echo "<td>".$row[3]."</td>";
            echo "<td>".$row[4]."</td>";
            echo "<td>".$row[5]."</td>";
            echo "<td><a href='delete.php?id=".$row[0]." 'class='btn btn-danger btn-sm'>Delete</a></td>";
            echo "</tr>";
        }

        mysqli_close($con);
        ?>

        </tbody>
    </table>

</div>
        </div>
        <div class="row">
            <div class="col-sm-12 footer">
                <!-- footer Design Come Here -->
                 <footer>
                  <?php
                        include("Footer.php");
                  ?>

                 </footer>
            </div>
        </div>
    </div>
</body>
</html>
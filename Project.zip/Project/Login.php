<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<style>

    
    
body{
    display:flex;
    justify-content:center;
    align-items:center;
    min-height:100vh;
    background-image:url("https://github.com/nikhilsingh16nikhil-star/FSD/blob/main/WhatsApp%20Image%202026-07-10%20at%208.02.25%20PM.jpeg?raw=true");
    background-size:cover;
    background-position:center;
    background-repeat:no-repeat;
    color: #FFFBDC;
}
.box{
    width: 300px;
    padding: 30px;
    background: rgba(255, 255, 255, 0.12);
    backdrop-filter: blur(18px);
    border: 1px solid rgba(255, 255, 255, 0.25);
    border-radius: 20px;
    box-shadow: 0, 15px, 35px, rgba(0, 0, 0, 0.4);
    text-align: center;
}
.box h2{
    color:rgba(0, 0, 0, 0.458); 
}

.box p{
    color:rgba(0, 0, 0, 0.458); 
 
}
 .icon{
    width:70px;
    height:70px;
    margin:auto;
    border-radius:50%;
    background:linear-gradient(135deg,#6A11CB,#2575FC);
    display:flex;
    justify-content:center;
    align-items:center;
    font-size:35px;
    color:white;
    box-shadow:0 8px 20px rgba(37,117,252,.5);
}
    form{
        margin-left: 10px;
        margin-top: 20px;
    }
    .i{
        width: 280px;
        margin-left: 5px;
        height: 30px;
        border-radius: 10px;
        border: none;
        color: #2D1B69
    }
    .i::placeholder{
        padding-left: 10px;
       color: #8A8A8A;

    }
   
    .btn{
        width: 300px;
        height: 35px;
         background:linear-gradient(135deg,#6A11CB,#2575FC);
        color: white;
        font-size: large;
        letter-spacing: 1px;
        border-radius: 15px;
        border:none;
        cursor: pointer;
    }
    .btn:hover{
        box-shadow: 0 10px 20px rgba(37, 117, 255, 0.5);
        color: tomato;
    }
    a{
        text-decoration: none;
        margin-top: 5px;
        margin-left: 20px;
        color: #190f40;
    
    }
    a:hover{
        color: tomato;
    }
    .remember{
        display: flex;
        align-items: center;
        gap: 20px;
        color: rgb(60, 54, 54);
        font-size: large;
        margin-bottom: 20px;
    }

</style>
</head>
<body>
    <div class="box">
        <div class="icon">
        <i class="fa-solid fa-user"></i>
        </div>
        <h2>Welcome Back</h2>
        <p>Login to continue to your aaccount</p>
        <form method="post">
            <?php
            if(isset($_REQUEST['login'])){
                $username=$_REQUEST['userE'];
                $password=$_REQUEST['userP'];
                $con=mysqli_connect("localhost","root","","dets_db");
                $qry="select * from tbluser where email='$username' and password='$password'";
                $result = mysqli_query($con,$qry);
                if(mysqli_num_rows($result)>0){
                 $row = mysqli_fetch_array($result);
                    session_start();
                    $_SESSION['uid']=$row[0];
                    $_SESSION['name']=$row[1];
                    header("location:dashboard.php");
                }
                else{
                    echo "invalid Username & Password";
                }
                mysqli_close($con);
            }





?>
                 <input  type="text" name="userE" placeholder="Enter Email Here" value="" class="i" required/><br><br>
            <input  type="password" name="userP" placeholder="Enter Password Here" value="" class="i" reurired/><br><br>
            <div class="remember">
            <input type="checkbox" name="userCheck"><label>Remember Me</label><br><br>
            </div>
            <input type="submit" name="login" value="Login" class="btn"/><br><br>
            <a href="Register.php">New User Click Here!!!!</a>

        </form>

    </div>
    
</body>
</html>
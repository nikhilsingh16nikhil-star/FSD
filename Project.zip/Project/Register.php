

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<style>

    
    
body{
    display:flex;
    justify-content:center;
    align-items:center;
    min-height:100vh;
    background-image:url("https://github.com/nikhilsingh16nikhil-star/FSD/blob/main/WhatsApp%20Image%202026-07-10%20at%208.02.25%20PM.jpeg?raw=true");
    background-size:cover;
    background-position:center;
    background-repeat:no-repeat;
    color: #FFFBDC;
}
.box{
    width: 300px;
    padding: 30px;
    background: rgba(255, 255, 255, 0.12);
    backdrop-filter: blur(18px);
    border: 1px solid rgba(255, 255, 255, 0.25);
    border-radius: 20px;
    box-shadow: 0, 15px, 35px, rgba(0, 0, 0, 0.4);
    text-align: center;
}
.box h2{
    color:rgba(0, 0, 0, 0.458); 
}

 .icon{
    width:70px;
    height:70px;
    margin:auto;
    border-radius:50%;
    background:linear-gradient(135deg,#6A11CB,#2575FC);
    display:flex;
    justify-content:center;
    align-items:center;
    font-size:35px;
    color:white;
    box-shadow:0 8px 20px rgba(37,117,252,.5);
}
    form{
        margin-left: 10px;
        margin-top: 20px;
    }
    .i{
        width: 280px;
        margin-left: 5px;
        height: 30px;
        border-radius: 10px;
        border: none;
        color: #2D1B69
    }
    .i::placeholder{
        padding-left: 20px;
       color: #8A8A8A;

    }
   
    .btn{
        width: 300px;
        height: 35px;
         background:linear-gradient(135deg,#6A11CB,#2575FC);
        color: white;
        font-size: large;
        letter-spacing: 1px;
        border-radius: 15px;
        border:none;
        cursor: pointer;
    }
    .btn:hover{
        box-shadow: 0 10px 20px rgba(37, 117, 255, 0.5);
        color: tomato;
    }
    a{
        text-decoration: none;
        margin-top: 5px;
        margin-left: 20px;
        color: #190f40;
    
    }
    a:hover{
        color: tomato;
    }
    .sign{
        color:green;
}
.unsign{
    color:red;
}
#r1 {
    color: green;
    font-weight: bold;
    margin-top: 10px;
}
#r2 {
    color: red;
    font-weight: bold;
    margin-top: 10px;
}
   

</style>
<script>
function validate() {
    let status = true;

    let no = document.getElementById("a2");
    let p1 = document.getElementById("a3");
    let p2 = document.getElementById("a4");

    if (no.value.length === 10 && Number(no.value) >= 6000000000 && Number(no.value) <= 9999999999) {
        no.style.border = "";
    } else {
        no.style.border = "3px solid red";
        status = false;
    }

    if (p1.value !== "" && p2.value !== "") {
        if (p1.value === p2.value) {
            p1.style.border = "";
            p2.style.border = "";
        } else {
            p1.style.border = "3px solid red";
            p2.style.border = "3px solid red";
            status = false;
        }
    } else {
        p1.style.border = "";
        p2.style.border = "";
    }

    return status;
}
</script>
</head>
<body>
    <div class="box">
        <div class="icon">
        <i class="fa-solid fa-user"></i>
        </div>
        <h2>Create New Account</h2>
        <form method="post" onsubmit="return validate()" oninput="validate()">
                       <?php

            if(isset($_POST['reg'])){
                $name=$_POST['txtname'];
                $email=$_POST['txtemail'];
                $number=$_POST['txtnumber'];
                $password=$_POST['txtpass'];
                $rdate=date("d-m-y h:i:s a");
                $conn = mysqli_connect("localhost","root","","dets_db");
                $query = "insert into tbluser(fullname,email,mobilenumber,password, regdate) values('$name', '$email' , '$number' , '$password','$rdate')";

               mysqli_query($conn,$query);

                if(mysqli_affected_rows($conn)>0)
                    echo "<p id='r1'>sign up successfully</p>";
                else
                      echo "<p id='r2'>Error in signup process !!! Try Again. </p>";

            }
            ?>
            
            <input type="text" name="txtname" placeholder="Username" value=""  required class="i"/><br><br>
            <input type="email" name="txtemail" placeholder="Email" value="" required  class="i"/><br><br>
            <input id="a2" type="number" name="txtnumber" placeholder="Mobile Number" value="" required  class="i"/><br><br>
            <input id="a3" type="password" name="txtpass" placeholder="Password" value="" required class="i"/><br><br>
            <input id="a4" type="password" name="txtcpass" placeholder="Confirm Password" value="" required class="i"/><br><br>
            <input type="submit" name="reg" value="Register" class="btn"/><br><br>
            <a href="Login.php">Go to Login Page!!!!</a>

        </form>

    </div>
    
</body>
</html>
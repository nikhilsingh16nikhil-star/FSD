<?php

session_start();
if(!isset($_SESSION['name'])){
    header("location:login.php");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link  rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12 header">
                <!-- Header Design Come Here -->
                 <?php
                 include("Header.php");
                 ?>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-2 sidebar">
                <!-- Header Design of sidemenu -->
                 <?php
                  include("sidebar.php");
                 ?>
            </div>
            <div class="col-sm-10">
                <!-- Content Area -->
                <h3 class="A">Add Expense</h3>
                <form>
                    <div class="form-group mb-2">
                    <label class="add">Select Date</label>
        <input type="date" name="txtD"  value=""   class="A"/>
</div>
        <div class="form-group mb-2">
               <label class="add">Categories</label>
               <select name="categories" class="A">
                <option></option>
                <option>Travel</option>
                <option>Food</option>
                <option>Apparel & Footwear</option>
                <option>Medicine</option>
                <option>Rent</option>
              <option>Fee</option>
             <option>Groceries</option>
                <option>Stationery</option>
                   <option>Entertaiment</option>

      </select>
</div>
                        <div class="form-group mb-2">
            <label class="add">Expense item Name's</label>
        <input type="text" name="txtE"  value="" placeholder="item name here"   class="A"/>
</div>
        <div class="form-group">
<label class="add">Expense Cost</label>
        <input type="text" name="txtcost"  value="" placeholder="Price here"   class="A"/>
</div>
             <input type="submit" name="btnA"  value="Add Expense Details"    class="addE"/>

                 </form>
                 <?php

if (isset($_REQUEST['btnA'])) {

    $date = $_REQUEST['txtD'];
    $cat = $_REQUEST['categories'];
    $itemname = $_REQUEST['txtE'];
    $cost = $_REQUEST['txtcost'];
    $uid = $_SESSION['uid'];

    $con = mysqli_connect("localhost", "root", "", "dets_db");

    $qry = "INSERT INTO tblexpence
            (userid, expensedate, categoryname, expenseitem, expensecost)
            VALUES
            ($uid, '$date', '$cat', '$itemname', $cost)";

    mysqli_query($con, $qry);

    if (mysqli_affected_rows($con) > 0)
        echo "<p class='text-success'>Expense Added Successfully !!!!</p>";
    else
        echo "<p class='text-danger'>Error in adding the expense !!!!</p>";

    mysqli_close($con);
}

?>
                 
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12 footer">
                <!-- footer Design Come Here -->
                 <footer>
                  <?php
                        include("Footer.php");
                  ?>

                 </footer>
            </div>
        </div>
    </div>
</body>
</html>
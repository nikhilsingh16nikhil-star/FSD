<?php

session_start();
if(!isset($_SESSION['name'])){
    header("location:login.php");
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link  rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12 header">
                <!-- Header Design Come Here -->
                 <?php
                 include("Header.php");
                 ?>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-2 sidebar">
                <!-- Header Design of sidemenu -->
                 <?php
                  include("sidebar.php");
                 ?>
            </div>
            <div class="col-sm-10">
                <!-- Content Area -->
                    <form method="post">
                    <label class="add">Start Date</label><br>
        <input type="date" name="txtsdate"  value=""   class="A"/><br><br>
            <label class="add">End Date</label><br>
                 <input type="date" name="txtedate"  value=""   class="A"/><br><br>
             <input type="submit" name="btnsubmit"  value="Show Report"    class="DayE"/>
          </form>

          <?php
                    if(isset($_POST['btnsubmit'])){
                        $sdate = $_POST['txtsdate'];
                        $edate = $_POST['txtedate'];
                        $uid = isset($_SESSION['uid']) ? (int)$_SESSION['uid'] : 0;
                        $con = mysqli_connect("localhost","root","","dets_db");
                        $qry = "SELECT * FROM tblexpence WHERE userid = $uid AND expensedate BETWEEN '$sdate' AND '$edate'";
                        $result = mysqli_query($con, $qry);
                        if(mysqli_num_rows($result)>0){
                            echo "<table class='table  table-striped'>";
                            echo "<tr style='background-color: rosybrown; color: white'>";
                            echo "<th>Expense Date</th>";
                            echo "<th>Categorie</th>";
                            echo "<th>Expense Item Name</th>";
                            echo "<th>Expense Amount</th>";
                            echo "</tr>";
                            $total = 0;
                            while($row = mysqli_fetch_array($result)){
                                echo "<tr>";
                                echo "<td>$row[2]</td>";
                                echo "<td>$row[3]</td>";
                                echo "<td>$row[4]</td>";
                                echo "<td>$row[5]</td>";
                                $total += $row[5];
                                echo "</tr>";
                            }
                            echo "<tr style='background-color: rosybrown; color: white; text-weight:bold; text-align:center'>";
                            echo "<td colspan='4''>Total Amount : $total</td>";
                            echo "</tr>";
                            echo "</table>";
                        }
                        else{
                            echo "<h3 class='text-warning'>No Record Found !!!</h3>";
                        }
                        mysqli_close($con);
                    }
                ?>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12 footer">
                <!-- footer Design Come Here -->
                 <footer>
                  <?php
                        include("Footer.php");
                  ?>

                 </footer>
            </div>
        </div>
    </div>
</body>
</html>
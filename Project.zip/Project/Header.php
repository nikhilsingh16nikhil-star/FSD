<div class="py-3 px-3 text-justify text-white">
    <h6 class="m-0">Expense Tracking System (Welcome <?php echo $_SESSION['name']; ?>)</h6>
</div>
<?php

session_start();
if(!isset($_SESSION['name'])){
    header("location:login.php");
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link  rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12 header">
                <!-- Header Design Come Here -->
                 <?php
                 include("Header.php");
                 ?>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-2 sidebar">
                <!-- Header Design of sidemenu -->
                 <?php
                  include("sidebar.php");
                 ?>
            </div>
            <div class="col-sm-10">
                <!-- Content Area -->
                   <form  method="post" enctype="multipart/form-data">
                 <label class="add">Select Profile Pic</label><br>
          <input type="file" name="txtfile"  value=""   class="p"/><br><br>
           <input type="submit" name="btnupload"  value="Upload Profile"   class="pic"/>
  
          </form>
         <?php
                    if(isset($_POST['btnupload'])){
                        if($_FILES['txtfile']['error'] == 0 ){
                            if($_FILES['txtfile']['type']=='image/jpeg' || $_FILES['txtfile']['type']=='image/png'){
                                    $from = $_FILES['txtfile']['tmp_name'];
                                    $to = $_SERVER['DOCUMENT_ROOT']."/PROJECT/picture/".$_FILES['txtfile']['name'];
                                    if(move_uploaded_file($from, $to)){
                                        $_SESSION['pic'] = "picture/".$_FILES['txtfile']['name'];
                                        echo "<p class='text-success'>Picture Uploaded</p>";
                                    }
                                    else
                                        echo "<p class='text-danger'>Error in uploading the file</p>";
                            }
                            else
                                echo "<p class='text-danger'>Invalid file format (Use jpeg, png type)</p>";
                        }
                        else{
                            echo "<p class='text-danger'>File is cruptted</p>";
                        }
                    }
                ?>

            </div>
        </div>
        <div class="row">
            <div class="col-sm-12 footer">
                <!-- footer Design Come Here -->
                 <footer>
                  <?php
                        include("Footer.php");
                  ?>

                 </footer>
            </div>
        </div>
    </div>
</body>
</html>
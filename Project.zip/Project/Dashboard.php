<?php

session_start();
if(!isset($_SESSION['name'])){
    header("location:login.php");
}
$con = mysqli_connect("localhost","root","","dets_db");
$uid = isset($_SESSION['uid']) ? $_SESSION['uid'] : 0;

$qry = "SELECT SUM(expensecost) AS total FROM tblexpence WHERE userid='$uid'";
$q1 = mysqli_query($con, $qry);
$r1 = mysqli_fetch_array($q1);
$totalexpense = $r1['total'];




$today = date("Y-m-d");
$query = "SELECT SUM(expensecost) AS total FROM tblexpence WHERE userid='$uid' AND expensedate='$today'";
$q2 = mysqli_query($con, $query);
$r2 = mysqli_fetch_array($q2);
$todayexpense = $r2['total'];



$month = date("m");
$year = date("Y");
$query1 = "SELECT SUM(expensecost) AS total FROM tblexpence WHERE userid='$uid' AND MONTH(expensedate)='$month' AND YEAR(Expensedate)='$year'";
$q3 = mysqli_query($con, $query1);
$r3 = mysqli_fetch_array($q3);
$monthexpense = $r3['total'];


$query3 = "SELECT SUM(expensecost) AS total FROM tblexpence WHERE userid='$uid' AND YEAR(expensedate)='$year'";
$q4 = mysqli_query($con, $query3);
$r4 = mysqli_fetch_array($q4);
$yearexpense = $r4['total'];


mysqli_close($con);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="style.css?v=1.0">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12 header">
                <!-- Header Design Come Here -->
                 <?php
                 include("Header.php");
                 ?>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-2 sidebar">
                <!-- Header Design of sidemenu -->
                 <?php
                  include("sidebar.php");
                 ?>
            </div>
            <div class="col-sm-10">
                <!-- Content Area -->
                  <div class="col-sm-12">
                    <h3 class="main">Welcome to the Dashboard</h3>
                    <p class="p1">Here you can manage your expenses, view reports, and update your profile. Use the sidebar to navigate through different sections of the application.</p>
                 </div>



       <div class="container maincontent">
      <div class="container-fluid mt-4">
     <div class="row text-center">

        <div class="col-sm-3 mb-3">
            <div class="circle blue">
                <div class="icon-box">
                    <i class="fas fa-wallet"></i>
                </div>
                <h5>Total Expense</h5>
                <div class="amount text-primary">
                    ₹<?php echo $totalexpense; ?>
                </div>
                <small>All Time</small>
            </div>
        </div>

        
        <div class="col-sm-3 mb-3">
            <div class="circle green">
                <div class="icon-box">
                    <i class="fas fa-calendar-day"></i>
                </div>
                <h5>Total Today Expense</h5>
                <div class="amount text-success">
                    ₹<?php echo $todayexpense; ?>
                </div>
                <small>Today</small>
            </div>
        </div>

        <div class="col-sm-3 mb-3">
            <div class="circle orange">
                <div class="icon-box">
                    <i class="fas fa-calendar-alt"></i>
                </div>
                <h5>Total Monthwise Expense</h5>
                <div class="amount" style="color:#fd7e14;">
                    ₹<?php echo $monthexpense; ?>
                </div>
                <small>This Month</small>
            </div>
        </div>

        
        <div class="col-sm-3 mb-3">
            <div class="circle purple">
                <div class="icon-box">
                    <i class="fas fa-chart-bar"></i>
                </div>
                <h5>Total Year Expense</h5>
                <div class="amount" style="color:#6f42c1;">
                    ₹<?php echo $yearexpense; ?>
                </div>
                <small>This Year</small>
            </div>
        </div>

    </div>
</div>
                 </div>
            </div>
              
        </div>
        <div class="row">
            <div class="col-sm-12 footer">
                <!-- footer Design Come Here -->
                 <footer>
                  <?php
                        include("Footer.php");
                  ?>

                 </footer>
            </div>
        </div>
    </div>
</body>
</html>